# streamlit_app.py
import streamlit as st

st.set_page_config(page_title="Supplier Risk App", layout="wide")
st.title("📦 Global Supplier Risk Intelligence Platform")
st.markdown("Select a module from the sidebar to begin.")
