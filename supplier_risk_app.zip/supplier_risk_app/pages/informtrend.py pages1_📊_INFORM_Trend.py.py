import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import pycountry

# Set page configuration
st.set_page_config(
    page_title="Global INFORM Risk Index Dashboard",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS to make it look vibrant
st.markdown("""
<style>
    .main {
        background-color: #0e1117;
    }
    .stApp {
        background-color: #0e1117;
    }
    .css-1kyxreq {
        background-color: #0e1117;
    }
    .css-1adrfps {
        background-color: #0e1117;
    }
    h1, h2, h3 {
        color: #00d4ff !important;
        font-weight: bold;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 24px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 4px 4px 0px 0px;
        padding: 10px 20px;
        background-color: #111;
        border-bottom-color: #111;
    }
    .stTabs [aria-selected="true"] {
        background-color: #0084ff !important;
        color: white !important;
        border-bottom-color: #0084ff !important;
    }
    .stButton>button {
        background-color: #0084ff;
        color: white;
        border-radius: 5px;
    }
    .stButton>button:hover {
        background-color: #00d4ff;
        color: black;
    }
    .reportview-container .sidebar-content {
        background-color: #0e1117;
    }
    .sidebar .sidebar-content {
        background-color: #0e1117;
    }
    .custom-metric {
        background-color: #1c1c1c;
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        border-left: 5px solid #00d4ff;
    }
</style>
""", unsafe_allow_html=True)

# Function to get country name from ISO3 code
@st.cache_data
def get_country_name_mapping():
    # Create a dictionary mapping ISO3 codes to country names
    country_map = {}
    
    # Using pycountry library to map ISO3 to country names
    for country in pycountry.countries:
        try:
            country_map[country.alpha_3] = country.name
        except AttributeError:
            continue
    
    # Add some common exceptions or special cases not handled by pycountry
    special_cases = {
        'PSE': 'Palestine',
        'KOS': 'Kosovo',
        'SSD': 'South Sudan',
        'TWN': 'Taiwan',
        'VEN': 'Venezuela',
        'BOL': 'Bolivia',
        'TZA': 'Tanzania',
        'COD': 'Democratic Republic of the Congo',
        'COG': 'Republic of Congo',
        'LAO': 'Laos',
        'VIR': 'U.S. Virgin Islands',
        'RUS': 'Russia',
        'IRN': 'Iran',
        'KOR': 'South Korea',
        'PRK': 'North Korea',
        'SYR': 'Syria',
        'MDA': 'Moldova'
    }
    
    country_map.update(special_cases)
    return country_map

# Load data
@st.cache_data
def load_data():
    # Replace with your actual data loading code
    df = pd.read_csv(r"C:\Users\User\OneDrive\Desktop\INFORM2024_TREND_2015_2024_v69_ALL_filtered.csv")  # Replace with your data file path
    
    # Get country name mapping
    country_map = get_country_name_mapping()
    
    # Add country name column based on ISO3 code
    df['CountryName'] = df['Iso3'].map(country_map)
    
    # For any missing country names, use the ISO3 code
    df['CountryName'] = df['CountryName'].fillna(df['Iso3'])
    
    return df

# Function to create the world map visualization
def create_map(data, selected_indicator, selected_year):
    filtered_data = data[(data['IndicatorName'] == selected_indicator) & 
                        (data['INFORMYear'] == selected_year)]
    
    # Create a colorscale based on indicator values
    max_score = filtered_data['IndicatorScore'].max()
    min_score = filtered_data['IndicatorScore'].min()
    
    # Determine if higher values are better or worse
    risk_indicators = ["Natural Hazard", "Hazard & Exposure Index", "Droughts probability", 
                    "disaster", "flood", "earthquake", "cyclone"]
    if any(term.lower() in selected_indicator.lower() for term in risk_indicators):
        color_scale = px.colors.diverging.RdYlGn_r  # Red is high (bad), green is low (good)
    else:
        color_scale = px.colors.diverging.RdYlGn  # Green is high (good), red is low (bad)
    
    # Create the choropleth map
    fig = px.choropleth(
        filtered_data, 
        locations='Iso3',
        color='IndicatorScore',
        hover_name='CountryName',  # Use country name for hover
        hover_data={
            'Iso3': False,  # Hide ISO3 code in hover
            'IndicatorScore': ':.2f',
            'CountryName': True
        },
        color_continuous_scale=color_scale,
        range_color=(min_score, max_score),
        title=f'{selected_indicator} ({selected_year})',
        template='plotly_dark'
    )
    
    fig.update_geos(
        showcoastlines=True, coastlinecolor="White",
        showland=True, landcolor="#333333",
        showocean=True, oceancolor="#000033",
        showlakes=True, lakecolor="#000033",
        showcountries=True, countrycolor="White",
        projection_type="natural earth"
    )
    
    fig.update_layout(
        height=700,
        margin=dict(l=0, r=0, t=50, b=0),
        paper_bgcolor="#0e1117",
        plot_bgcolor="#0e1117",
        geo=dict(
            bgcolor="#0e1117",
        ),
        title_font=dict(
            family="Arial, sans-serif",
            size=24,
            color="#00d4ff"
        ),
        coloraxis_colorbar=dict(
            title="Score",
            thicknessmode="pixels", thickness=20,
            lenmode="pixels", len=300,
            yanchor="middle", y=0.5,
            ticks="outside", ticksuffix="",
            dtick=2
        )
    )
    
    return fig

# Function to create a trend chart for selected countries
def create_trend_chart(data, selected_indicator, selected_countries):
    if not selected_countries:
        return None
    
    # Filter data for the selected indicator and countries
    filtered_data = data[
        (data['IndicatorName'] == selected_indicator) & 
        (data['CountryName'].isin(selected_countries))
    ]
    
    fig = px.line(
        filtered_data, 
        x='INFORMYear', 
        y='IndicatorScore', 
        color='CountryName',  # Use country name for color groups
        markers=True,
        title=f'Trend for {selected_indicator} by Country',
        template='plotly_dark',
        color_discrete_sequence=px.colors.qualitative.Bold
    )
    
    fig.update_layout(
        height=400,
        paper_bgcolor="#0e1117",
        plot_bgcolor="#111111",
        font=dict(color="white"),
        legend=dict(
            title="Countries",
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="center",
            x=0.5,
            bgcolor="#1c1c1c",
            bordercolor="#444444"
        ),
        xaxis=dict(
            title="Year",
            gridcolor='#333333',
            tickformat='d'  # Display years as integers
        ),
        yaxis=dict(
            title="Score",
            gridcolor='#333333'
        )
    )
    
    return fig

# Function to create a bar chart for comparing countries
def create_bar_chart(data, selected_indicator, selected_year, selected_countries):
    if not selected_countries:
        return None
    
    filtered_data = data[
        (data['IndicatorName'] == selected_indicator) & 
        (data['INFORMYear'] == selected_year) &
        (data['CountryName'].isin(selected_countries))
    ]
    
    # Sort by score
    filtered_data = filtered_data.sort_values('IndicatorScore', ascending=False)
    
    # Generate a vibrant color scale for the bars
    colors = px.colors.qualitative.Bold
    if len(filtered_data) > len(colors):
        colors = colors * (len(filtered_data) // len(colors) + 1)
    
    fig = px.bar(
        filtered_data,
        x='CountryName',  # Use country name on x-axis
        y='IndicatorScore',
        color='CountryName',  # Use country name for color
        color_discrete_sequence=colors[:len(filtered_data)],
        title=f'Comparison for {selected_indicator} ({selected_year})',
        template='plotly_dark'
    )
    
    fig.update_layout(
        height=400,
        paper_bgcolor="#0e1117",
        plot_bgcolor="#111111",
        font=dict(color="white"),
        showlegend=False,
        xaxis=dict(
            title="Country",
            gridcolor='#333333',
            tickangle=45  # Angle the country names for better readability
        ),
        yaxis=dict(
            title="Score",
            gridcolor='#333333'
        )
    )
    
    return fig

# Main dashboard
def main():
    # Get data
    try:
        data = load_data()
    except Exception as e:
        st.error(f"Error loading data: {e}")
        st.error("Please ensure your data file is correctly located and formatted.")
        return
    
    # Dashboard header
    st.markdown("<h1 style='text-align: center;'>🌎 Global INFORM Risk Index Dashboard 🌎</h1>", unsafe_allow_html=True)
    
    # Sidebar for filters
    st.sidebar.markdown("<h2>Dashboard Controls</h2>", unsafe_allow_html=True)
    
    # Get all unique indicators and years
    indicators = sorted(data['IndicatorName'].unique())
    years = sorted(data['INFORMYear'].unique(), reverse=True)
    
    # Get all unique countries with their names
    countries = sorted(data['CountryName'].unique())
    
    # Create filters
    selected_indicator = st.sidebar.selectbox("Select Indicator", indicators)
    selected_year = st.sidebar.selectbox(
        "Select Year", 
        years, 
        index=0 if years and 2024 in years else 0
    )
    
    # Multi-select for countries to compare
    selected_countries = st.sidebar.multiselect(
        "Select Countries to Compare (up to 10)",
        countries,
        default=countries[:5] if len(countries) >= 5 else countries
    )
    
    # About this indicator
    st.sidebar.markdown("---")
    st.sidebar.markdown("<h3>About this Indicator</h3>", unsafe_allow_html=True)
    
    # This would ideally come from your data or a separate metadata file
    indicator_descriptions = {
        "Total affected by Natural Disasters last 3 years": "Total number of people affected by natural disasters in the last 3 years.",
        "Access to electricity": "Percentage of population with access to electricity.",
        "Physical exposure to tropical cyclones": "Population potentially exposed to tropical cyclones.",
        "Road density": "Kilometers of road per 100 sq. kilometers of land area.",
        "Economic Dependency": "Extent to which a country's economy depends on external factors.",
        "Corruption Perception Index": "Perceived levels of public sector corruption.",
        "Government Effectiveness": "Quality of public services and civil service, and degree of independence from political pressures.",
        "Droughts probability and historical impact": "Likelihood of drought occurrence and severity of past events.",
        "Physical exposure to coastal flood": "Population potentially exposed to coastal flooding.",
        "Physical exposure to river flood": "Population potentially exposed to river flooding.",
        "Natural Hazard": "Composite indicator of exposure to natural hazards.",
        "Hazard & Exposure Index": "Combined index measuring hazard exposure and vulnerability.",
        "Population density": "Number of people per square kilometer of land area.",
        "Human Development Index": "Composite measure of health, education, and income dimensions.",
        "Multidimensional Poverty Index": "Measure of acute multidimensional poverty."
    }
    
    description = indicator_descriptions.get(selected_indicator, "No description available for this indicator.")
    st.sidebar.markdown(f"<p>{description}</p>", unsafe_allow_html=True)
    
    # Main dashboard area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # World Map
        fig_map = create_map(data, selected_indicator, selected_year)
        st.plotly_chart(fig_map, use_container_width=True)
    
    with col2:
        # Key metrics for the selected indicator
        st.markdown("<h3>Key Metrics</h3>", unsafe_allow_html=True)
        
        filtered_data = data[(data['IndicatorName'] == selected_indicator) & 
                            (data['INFORMYear'] == selected_year)]
        
        # Calculate metrics
        avg_score = filtered_data['IndicatorScore'].mean()
        max_score = filtered_data['IndicatorScore'].max()
        min_score = filtered_data['IndicatorScore'].min()
        
        # Find countries with max and min scores
        max_country = filtered_data[filtered_data['IndicatorScore'] == max_score]['CountryName'].values[0]
        min_country = filtered_data[filtered_data['IndicatorScore'] == min_score]['CountryName'].values[0]
        
        # Display metrics in colored boxes
        metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
        
        with metrics_col1:
            st.markdown(f"""
            <div class="custom-metric">
                <h4 style="color: #00d4ff;">Global Average</h4>
                <h2 style="margin-top: 10px; color: white;">{avg_score:.2f}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        with metrics_col2:
            st.markdown(f"""
            <div class="custom-metric">
                <h4 style="color: #00d4ff;">Highest Score</h4>
                <h2 style="margin-top: 10px; color: white;">{max_score:.2f}</h2>
                <p style="margin-top: 5px; color: #aaa;">{max_country}</p>
            </div>
            """, unsafe_allow_html=True)
        
        with metrics_col3:
            st.markdown(f"""
            <div class="custom-metric">
                <h4 style="color: #00d4ff;">Lowest Score</h4>
                <h2 style="margin-top: 10px; color: white;">{min_score:.2f}</h2>
                <p style="margin-top: 5px; color: #aaa;">{min_country}</p>
            </div>
            """, unsafe_allow_html=True)
    
    # Create tabs for different comparative visualizations
    st.markdown("<h3>Comparative Analysis</h3>", unsafe_allow_html=True)
    tab1, tab2 = st.tabs(["Country Comparison", "Trend Analysis"])
    
    with tab1:
        if selected_countries:
            fig_bar = create_bar_chart(data, selected_indicator, selected_year, selected_countries)
            st.plotly_chart(fig_bar, use_container_width=True)
        else:
            st.info("Please select countries to compare in the sidebar.")
    
    with tab2:
        if selected_countries:
            fig_trend = create_trend_chart(data, selected_indicator, selected_countries)
            st.plotly_chart(fig_trend, use_container_width=True)
        else:
            st.info("Please select countries to compare in the sidebar.")
    
    # Distribution histogram
    st.markdown("<h3>Global Distribution</h3>", unsafe_allow_html=True)
    filtered_data = data[(data['IndicatorName'] == selected_indicator) & 
                        (data['INFORMYear'] == selected_year)]
    
    fig_hist = px.histogram(
        filtered_data, 
        x='IndicatorScore',
        nbins=20,
        color_discrete_sequence=['#00d4ff'],
        title=f'Distribution of {selected_indicator} Scores ({selected_year})'
    )
    
    fig_hist.update_layout(
        template='plotly_dark',
        paper_bgcolor="#0e1117",
        plot_bgcolor="#111111",
        xaxis=dict(title="Score", gridcolor='#333333'),
        yaxis=dict(title="Number of Countries", gridcolor='#333333')
    )
    
    st.plotly_chart(fig_hist, use_container_width=True)
    
    # Add a data table with the top and bottom countries
    st.markdown("<h3>Top and Bottom Countries</h3>", unsafe_allow_html=True)
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("<h4 style='color: #00d4ff;'>Top 10 Countries</h4>", unsafe_allow_html=True)
        top_countries = filtered_data.sort_values('IndicatorScore', ascending=False).head(10)
        st.dataframe(
            top_countries[['CountryName', 'IndicatorScore']].set_index('CountryName'),
            use_container_width=True,
            height=400
        )
    
    with col2:
        st.markdown("<h4 style='color: #00d4ff;'>Bottom 10 Countries</h4>", unsafe_allow_html=True)
        bottom_countries = filtered_data.sort_values('IndicatorScore').head(10)
        st.dataframe(
            bottom_countries[['CountryName', 'IndicatorScore']].set_index('CountryName'),
            use_container_width=True,
            height=400
        )
    
    # Footer with data source information
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #888;">
        <p>Data source: INFORM Risk Index | Dashboard created with Streamlit and Plotly</p>
        <p>Last updated: 2023</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
