import streamlit as st
import pandas as pd
import numpy as np

# Simulated INFORM risk scores (normally you'd load this from a CSV)
simulated_risk_data = {
    'India': {
        'Road density_y': 0.6,
        'Natural Hazard_y': 0.7,
        'Corruption Perception Index_y': 0.4,
        'Government Effectiveness_y': 0.45,
        'Economic Dependency_y': 0.5,
        'Multidimensional Poverty Index_y': 0.55,
        'Human Development Index_y': 0.65,
        'Access to electricity_y': 0.8
    },
    'USA': {
        'Road density_y': 0.9,
        'Natural Hazard_y': 0.3,
        'Corruption Perception Index_y': 0.85,
        'Government Effectiveness_y': 0.9,
        'Economic Dependency_y': 0.2,
        'Multidimensional Poverty Index_y': 0.1,
        'Human Development Index_y': 0.95,
        'Access to electricity_y': 0.99
    },
    'China': {
        'Road density_y': 0.8,
        'Natural Hazard_y': 0.6,
        'Corruption Perception Index_y': 0.5,
        'Government Effectiveness_y': 0.7,
        'Economic Dependency_y': 0.3,
        'Multidimensional Poverty Index_y': 0.3,
        'Human Development Index_y': 0.75,
        'Access to electricity_y': 0.95
    }
}

st.title("🤖 Supplier Suitability Chatbot")

st.markdown("Talk to our AI to evaluate a supplier's reliability based on input features and origin country.")

# --- Inputs ---
supplier_country = st.selectbox("🌍 Select Supplier Country", list(simulated_risk_data.keys()))

st.subheader("📦 Supplier Operational Metrics")

cargo_condition_status = st.number_input("Cargo Condition Score (0–1)", min_value=0.0, max_value=1.0, value=0.8)
historical_demand = st.number_input("Historical Demand (e.g. 5000)", min_value=0.0, value=5000.0)
shipping_costs = st.number_input("Shipping Costs ($)", min_value=0.0, value=300.0)
delivery_time_deviation = st.number_input("Delivery Time Deviation (hrs)", min_value=0.0, value=2.0)
lead_time_days = st.number_input("Lead Time (days)", min_value=0.0, value=7.0)

if st.button("🧠 Assess Supplier"):
    # Simulated logic for scoring
    base_score = 0.5

    if cargo_condition_status > 0.9:
        base_score += 0.15
    elif cargo_condition_status < 0.6:
        base_score -= 0.1

    if delivery_time_deviation < 3:
        base_score += 0.1
    else:
        base_score -= 0.05

    if shipping_costs > 1000:
        base_score -= 0.1

    # Country effect
    country_risks = simulated_risk_data[supplier_country]
    risk_penalty = (1 - country_risks['Government Effectiveness_y']) * 0.1
    base_score -= risk_penalty

    # Final score clamp
    risk_score = round(min(max(base_score, 0.0), 1.0), 3)

    # Response
    st.markdown(f"### 🤖 Risk Score: **{risk_score}**")

    if risk_score < 0.3:
        st.success("✅ This supplier appears **low risk**.")
        st.markdown("Low delivery deviation and strong cargo quality indicate a robust logistics operation.")
    elif risk_score < 0.7:
        st.warning("⚠️ This supplier is **moderately risky**.")
        st.markdown("Consider monitoring delivery fluctuations or cost spikes.")
    else:
        st.error("❌ This supplier appears **highly risky**.")
        st.markdown("Unstable delivery metrics and/or country risk affects overall supplier performance.")

    # Show risk insights
    with st.expander("🔍 Country Risk Factors Considered"):
        st.json(country_risks)
