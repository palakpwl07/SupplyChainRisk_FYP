import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# Page configuration
st.set_page_config(
    page_title="Supply Chain Risk Dashboard",
    page_icon="🚚",
    layout="wide"
)

# Assuming the dataframe is loaded as df
# For demonstration purposes, I'll simulate loading the data
# In a real implementation, you would replace this with loading your actual data
@st.cache_data
def load_data():
    df=pd.read_csv(r"C:\Users\User\OneDrive\Desktop\dynamic_supply_chain_logistics_dataset_with_country.csv")
    # Simulate loading data
    return df  # Assuming 'df' is your dataframe variable

try:
    df = load_data()
    
    # Title and description
    st.title("Supply Chain Risk Dashboard")
    st.markdown("This dashboard provides insights into supply chain risks, performance metrics, and inventory management.")
    
    # Create product filter
    product_list = sorted(df['product_id'].unique())
    selected_product = st.sidebar.selectbox("Select Product", ["All Products"] + product_list)
    
    # Filter data based on selection
    if selected_product != "All Products":
        filtered_df = df[df['product_id'] == selected_product]
    else:
        filtered_df = df
    
    # Top 3 Reliable Suppliers Section
    st.subheader("Top 3 Most Reliable Suppliers")
    
    # Get top 3 suppliers by reliability
    top_suppliers = filtered_df.groupby(['supplier_id', 'supplier_country'])[
        'supplier_reliability_score'
    ].mean().reset_index().sort_values('supplier_reliability_score', ascending=False).head(3)
    
    # Display top suppliers in a horizontal layout
    top_cols = st.columns(3)
    
    for i, (_, row) in enumerate(top_suppliers.iterrows()):
        with top_cols[i]:
            st.markdown(f"""
            ### #{i+1}: {row['supplier_id']}
            **Reliability Score:** {row['supplier_reliability_score']:.2f}/10
            
            **Location:** {row['supplier_country']}
            """)
            
            # Create a small indicator of reliability
            fig = go.Figure(go.Indicator(
                mode="gauge+number",
                value=row['supplier_reliability_score'],
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "Reliability"},
                gauge={
                    'axis': {'range': [0, 10]},
                    'bar': {'color': "darkblue"},
                    'steps': [
                        {'range': [0, 3.33], 'color': "red"},
                        {'range': [3.33, 6.66], 'color': "orange"},
                        {'range': [6.66, 10], 'color': "green"}
                    ]
                }
            ))
            fig.update_layout(height=150, margin=dict(l=20, r=20, t=30, b=20))
            # Add unique key for each chart
            st.plotly_chart(fig, use_container_width=True, key=f"gauge_{i}")
    
    st.markdown("---")
    
    # Create dashboard layout for the rest of the dashboard
    col1, col2 = st.columns([1, 2])
    
    # Key Metrics in first column
    with col1:
        st.subheader("Key Risk Metrics")
        
        # Risk classification distribution
        risk_counts = filtered_df['risk_classification'].value_counts().reset_index()
        risk_counts.columns = ['Risk Level', 'Count']
        
        # Create a color map for risk levels
        risk_colors = {
            'Low': 'green',
            'Medium': 'orange',
            'High': 'red'
        }
        
        # Convert to a color list for the chart
        colors = [risk_colors.get(risk, 'gray') for risk in risk_counts['Risk Level']]
        
        fig_risk = px.bar(
            risk_counts,
            x='Risk Level',
            y='Count',
            color='Risk Level',
            color_discrete_map=risk_colors,
            title="Risk Classification Distribution"
        )
        st.plotly_chart(fig_risk, use_container_width=True, key="risk_dist_chart")
        
        # Average metrics
        st.metric("Avg. Disruption Likelihood", f"{filtered_df['disruption_likelihood_score'].mean():.2f}")
        st.metric("Avg. Delay Probability", f"{filtered_df['delay_probability'].mean():.2f}")
        st.metric("Avg. Route Risk Level", f"{filtered_df['route_risk_level'].mean():.2f}")
        
        # Supplier reliability
        fig_reliability = px.histogram(
            filtered_df,
            x="supplier_reliability_score",
            nbins=20,
            title="Supplier Reliability Distribution",
            color_discrete_sequence=['#636EFA']
        )
        st.plotly_chart(fig_reliability, use_container_width=True, key="reliability_hist")
    
    # Detailed analysis in second column
    with col2:
        # Create tabs for different views
        tab1, tab2, tab3 = st.tabs(["Supply Chain Performance", "Inventory & Lead Time", "Supplier Analysis"])
        
        with tab1:
            # Supply Chain Performance Metrics
            st.subheader("Supply Chain Performance Metrics")
            
            # Correlation heatmap of risk factors
            risk_cols = [
                'disruption_likelihood_score', 
                'delay_probability', 
                'route_risk_level',
                'supplier_reliability_score', 
                'customs_clearance_time',
                'delivery_time_deviation'
            ]
            
            corr = filtered_df[risk_cols].corr()
            
            fig_corr = px.imshow(
                corr,
                text_auto=True,
                aspect="auto",
                color_continuous_scale="RdBu_r",
                title="Correlation of Risk Factors"
            )
            st.plotly_chart(fig_corr, use_container_width=True, key="corr_heatmap")
            
            # Delivery time deviation vs likelihood score
            fig_scatter = px.scatter(
                filtered_df, 
                x='disruption_likelihood_score',
                y='delivery_time_deviation',
                color='risk_classification',
                color_discrete_map=risk_colors,
                opacity=0.7,
                title='Delivery Time Deviation vs. Disruption Likelihood',
                hover_data=['product_id', 'supplier_id']
            )
            st.plotly_chart(fig_scatter, use_container_width=True, key="dev_likelihood_scatter")
        
        with tab2:
            # Inventory and Lead Time Analysis
            st.subheader("Inventory & Lead Time Analysis")
            
            # Create two charts in one row
            col_a, col_b = st.columns(2)
            
            with col_a:
                # Inventory level histogram
                fig_inv = px.histogram(
                    filtered_df,
                    x="warehouse_inventory_level",
                    nbins=30,
                    title="Warehouse Inventory Level Distribution",
                    color_discrete_sequence=['#00CC96']
                )
                st.plotly_chart(fig_inv, use_container_width=True, key="inv_hist")
            
            with col_b:
                # Lead time histogram
                fig_lead = px.histogram(
                    filtered_df,
                    x="lead_time_days",
                    nbins=30,
                    title="Lead Time Distribution (Days)",
                    color_discrete_sequence=['#AB63FA']
                )
                st.plotly_chart(fig_lead, use_container_width=True, key="lead_time_hist")
            
            # Scatter plot for inventory vs historical demand
            fig_inv_demand = px.scatter(
                filtered_df,
                x="historical_demand",
                y="warehouse_inventory_level",
                color="risk_classification",
                color_discrete_map=risk_colors,
                title="Inventory Level vs Historical Demand",
                opacity=0.7,
                hover_data=['product_id']
            )
            st.plotly_chart(fig_inv_demand, use_container_width=True, key="inv_demand_scatter")
        
        with tab3:
            # Supplier Analysis
            st.subheader("Supplier Analysis")
            
            # Top Supplier Locations on Map - more detailed than the top 3 section
            if len(top_suppliers) > 0:
                # Create supplier country map highlighting top 3 suppliers
                top_supplier_ids = top_suppliers['supplier_id'].tolist()
                
                # Create a dataframe for the map with all suppliers
                map_df = filtered_df[['supplier_id', 'supplier_country']].drop_duplicates()
                
                # Add a column to identify top suppliers
                map_df['is_top'] = map_df['supplier_id'].apply(lambda x: 'Top Supplier' if x in top_supplier_ids else 'Other Supplier')
                
                # Count suppliers by country
                map_data = map_df.groupby(['supplier_country', 'is_top']).size().reset_index(name='Count')
                
                # Create the map
                fig_map = px.choropleth(
                    map_data,
                    locations="supplier_country",
                    locationmode="country names",
                    color="Count",
                    color_continuous_scale="Viridis",
                    hover_data=['is_top'],
                    title="Supplier Distribution by Country (Top Suppliers Highlighted)"
                )
                
                # Add markers for top supplier countries
                top_countries = map_df[map_df['is_top'] == 'Top Supplier']['supplier_country'].unique()
                
                for country in top_countries:
                    fig_map.add_annotation(
                        x=country,
                        text="★",
                        showarrow=True,
                        font=dict(size=20, color="gold")
                    )
                
                st.plotly_chart(fig_map, use_container_width=True, key="supplier_map_top")
            else:
                # Fallback to regular map if no top suppliers
                supplier_country_counts = filtered_df['supplier_country'].value_counts().reset_index()
                supplier_country_counts.columns = ['Country', 'Count']
                
                fig_map = px.choropleth(
                    supplier_country_counts,
                    locations="Country",
                    locationmode="country names",
                    color="Count",
                    color_continuous_scale="Viridis",
                    title="Supplier Distribution by Country"
                )
                st.plotly_chart(fig_map, use_container_width=True, key="supplier_map_regular")
            
            # Top suppliers by reliability - extended beyond the top 3
            all_top_suppliers = filtered_df.groupby('supplier_id')['supplier_reliability_score'].mean().reset_index()
            all_top_suppliers = all_top_suppliers.sort_values('supplier_reliability_score', ascending=False).head(10)
            
            fig_top_supp = px.bar(
                all_top_suppliers,
                x='supplier_id',
                y='supplier_reliability_score',
                title="Top 10 Suppliers by Reliability Score",
                color='supplier_reliability_score',
                color_continuous_scale=px.colors.sequential.Viridis
            )
            
            # Highlight top 3 with different color
            if len(top_suppliers) > 0:
                top3_ids = top_suppliers['supplier_id'].tolist()
                for i, supplier_id in enumerate(all_top_suppliers['supplier_id']):
                    if supplier_id in top3_ids:
                        fig_top_supp.data[0].marker.color = list(fig_top_supp.data[0].marker.color)
                        fig_top_supp.data[0].marker.color[i] = 'gold'
            
            st.plotly_chart(fig_top_supp, use_container_width=True, key="top10_suppliers_bar")
    
    # Additional section for shipping and customs analysis
    st.subheader("Shipping & Customs Analysis")
    col3, col4 = st.columns(2)
    
    with col3:
        # Shipping costs analysis
        fig_shipping = px.box(
            filtered_df,
            x="risk_classification",
            y="shipping_costs",
            color="risk_classification",
            color_discrete_map=risk_colors,
            title="Shipping Costs by Risk Classification"
        )
        st.plotly_chart(fig_shipping, use_container_width=True, key="shipping_costs_box")
    
    with col4:
        # Customs clearance time analysis
        fig_customs = px.violin(
            filtered_df,
            x="risk_classification",
            y="customs_clearance_time",
            color="risk_classification",
            color_discrete_map=risk_colors,
            box=True,
            title="Customs Clearance Time by Risk Classification"
        )
        st.plotly_chart(fig_customs, use_container_width=True, key="customs_time_violin")
    
    # Data table with key columns
    if st.checkbox("Show Raw Data"):
        display_cols = [
            'product_id', 'supplier_id', 'supplier_country', 
            'risk_classification', 'disruption_likelihood_score',
            'warehouse_inventory_level', 'lead_time_days',
            'shipping_costs', 'customs_clearance_time'
        ]
        st.dataframe(filtered_df[display_cols].head(100))

except Exception as e:
    st.error(f"An error occurred: {e}")
    st.info("Please ensure your data is correctly loaded and contains all required columns.")
